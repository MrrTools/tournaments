package com.tournament.fifa_tournament;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifaTournamentApplicationTests {

	@Test
	void contextLoads() {
	}

}
